using UnityEngine;

[System.Serializable]
public class SampleClass1 : MonoBehaviour
{
    public int myInt = 1;
    public float myFloat = 0f;
    public string myString = "hi";
    public Vector3 myVector3 = Vector3.forward;
    public Color myColor = Color.blue;
}