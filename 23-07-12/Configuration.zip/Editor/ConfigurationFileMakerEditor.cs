using UnityEditor;
using UnityEngine;

public class ConfigurationFileMakerEditor : EditorWindow
{
    private ConfigurationFileMaker fileMaker;

    [MenuItem("Tools/ConfigurationFileMakerEditor")]
    public static void OpenWindow()
    { 
        ConfigurationFileMakerEditor window = GetWindow<ConfigurationFileMakerEditor>();
        window.titleContent = new GUIContent("ConfigurationFileMaker");
        window.Show();
    }

    private void OnEnable()
    {
        if (FindObjectOfType<ConfigurationFileMaker>() != null)
        {
            fileMaker = FindObjectOfType<ConfigurationFileMaker>(); 
        }
        else
        {
            fileMaker = new ConfigurationFileMaker();
        }
    }

    private void OnGUI()
    {
        GUILayout.Label("Configuration File Maker", EditorStyles.boldLabel);
        fileMaker.classInstance = (MonoBehaviour)EditorGUILayout.ObjectField("Class Instance", fileMaker.classInstance, typeof(MonoBehaviour), true);

        if (GUILayout.Button("Make Configuration File"))
        {
            fileMaker.MakeConfigurationFile();
        }
    }
}