using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JsonConfigurationFileHolder
{
    public string className;
    public string jsonData;
}

public class ConfigurationFileMaker : MonoBehaviour
{
    public MonoBehaviour classInstance;

    public void MakeConfigurationFile()
    {
        JsonConfigurationFileHolder jsonConfigurationFileHolder = new JsonConfigurationFileHolder();
        jsonConfigurationFileHolder.className = classInstance.GetType().Name;
        jsonConfigurationFileHolder.jsonData = JsonUtility.ToJson(classInstance);

        string json = JsonUtility.ToJson(jsonConfigurationFileHolder);
        string filePath = GetUniqueFilePath(jsonConfigurationFileHolder.className);
        
        string directoryPath = System.IO.Path.GetDirectoryName(filePath);
        if (!System.IO.Directory.Exists(directoryPath))
        {
            System.IO.Directory.CreateDirectory(directoryPath);
        }
        
        System.IO.File.WriteAllText(filePath, json);

        Debug.Log("Configuration file created: " + filePath);
    }

    private string GetUniqueFilePath(string className)
    {
        string directoryPath = Application.dataPath + "/Results/ConfigurationFiles/";
        string fileName = className + " DefaultConfigurationFile" + ".json";
        string filePath = System.IO.Path.Combine(directoryPath, fileName);

        // // 동일한 이름의 파일이 이미 존재하는 경우, 새로운 파일 이름 생성
        // int counter = 1;
        // while (System.IO.File.Exists(filePath))
        // {
        //     fileName = className + " DefaultConfigurationFile" + counter.ToString() + ".json";
        //     filePath = System.IO.Path.Combine(directoryPath, fileName);
        //     counter++;
        // }

        return filePath;
    }
}